import pandas as pd
import numpy as np
import cv2
import matplotlib.pyplot as plt
from shapely.geometry import Polygon


dir = "csv/"
num = "n1062"
ns_data = pd.read_csv( dir + num + "_nes.csv",header=None).values
e1_data = pd.read_csv( dir + num + "_e1.csv", header=None).values
e2_data = pd.read_csv( dir + num + "_e2.csv", header=None).values
fig = plt.figure()
plt.xlim(0,1.1)
plt.ylim(0,1.1)
plt.xticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
plt.yticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
#supplementary_fig1
#per = Polygon(ns_data)      
#x, y = per.exterior.xy
#plt.fill(x, y, c="green",alpha=0.5)
plt.plot(ns_data[:,0], ns_data[:,1], c="grey",marker="o")
plt.plot(ns_data[23,0], ns_data[23,1], c="red",marker="s",markersize=12)
plt.plot(ns_data[75,0], ns_data[75,1], c="blue",marker="D",markersize=12)
fig.savefig("1062_1_ns.pdf",bbox_inches='tight')

plt.close()

#exit

fig = plt.figure()
plt.xlim(0,1.1)
plt.ylim(0,1.1)
plt.xticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
plt.yticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
plt.plot(e1_data[:,0], e1_data[:,1], c="grey",marker="o")
plt.plot(e1_data[23,0], e1_data[23,1], c="red",marker="s",markersize=12)
plt.plot(e1_data[75,0], e1_data[75,1], c="blue",marker="D",markersize=12)
fig.savefig("1062_e1.pdf",bbox_inches='tight')

plt.close()


fig = plt.figure()
plt.xlim(0,1.1)
plt.ylim(0,1.1)
plt.xticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
plt.yticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
plt.plot(e2_data[:,0], e2_data[:,1], c="grey",marker="o")
plt.plot(e2_data[23,0], e2_data[23,1], c="red",marker="s",markersize=12)
plt.plot(e2_data[75,0], e2_data[75,1], c="blue",marker="D",markersize=12)

fig.savefig("1062_e2.pdf",bbox_inches='tight')

plt.close()

dir = "csv/"
num = "chd1"
ns_data = pd.read_csv( dir + num + "_nes.csv",header=None).values
e1_data = pd.read_csv( dir + num + "_e1.csv", header=None).values
e2_data = pd.read_csv( dir + num + "_e2.csv", header=None).values
fig = plt.figure()
plt.xlim(0,1.1)
plt.ylim(0,1.1)
plt.xticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
plt.yticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
#supplementary_fig1
#per = Polygon(ns_data)      
#x, y = per.exterior.xy
#plt.fill(x, y, c="green",alpha=0.5)
plt.plot(ns_data[:,0], ns_data[:,1], c="grey",marker="o")
plt.plot(ns_data[12,0], ns_data[12,1], c="red",marker="s",markersize=12)
plt.plot(ns_data[26,0], ns_data[26,1], c="blue",marker="D",markersize=12)

fig.savefig("1_ns.pdf",bbox_inches='tight')

plt.close()

fig = plt.figure()
plt.xlim(0,1.1)
plt.ylim(0,1.1)
plt.xticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
plt.yticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
plt.plot(e1_data[:,0], e1_data[:,1], c="grey",marker="o")
plt.plot(e1_data[12 ,0], e1_data[12,1], c="red",marker="s",markersize=12)
plt.plot(e1_data[26,0], e1_data[26,1], c="blue",marker="D",markersize=12)
fig.savefig("1_e1.pdf",bbox_inches='tight')

plt.close()


fig = plt.figure()
plt.xlim(0,1.1)
plt.ylim(0,1.1)
plt.xticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
plt.yticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
plt.plot(e2_data[:,0], e2_data[:,1], c="grey",marker="o")
plt.plot(e2_data[12,0], e2_data[12,1], c="red",marker="s",markersize=12)
plt.plot(e2_data[26,0], e2_data[26,1], c="blue",marker="D",markersize=12)
fig.savefig("1_e2.pdf",bbox_inches='tight')

plt.close()

