import pandas as pd
from sklearn.metrics import roc_curve,auc
import sys

tmp = pd.read_csv("AI_doctor.csv")
name = sys.argv[1] #"fellow_1"
fpr,tpr,a = roc_curve(tmp["TRUE"],tmp[name],pos_label=1)

for i in range(len(fpr)):
    print(fpr[i],tpr[i])
print(name)
print("auc")
print(auc(fpr,tpr))
tp = 0.0
fp = 0.0
tn = 0.0
fn = 0.0
p = 20.0
n = 20.0
for i in range(40):
    if(tmp[name][i]  > 0.5 and tmp["TRUE"][i] > 0.5):
        tp = tp + 1.0
    if(tmp[name][i] > 0.5 and tmp["TRUE"][i] < 0.5):
       fp = fp + 1.0 
    if(tmp[name][i] < 0.5 and tmp["TRUE"][i] < 0.5 ):
       tn = tn + 1.0
    if(tmp[name][i] < 0.5 and tmp["TRUE"][i] > 0.5):
       fn = fn + 1
print("acc,fpr,tpr,precision,recall,F1")
print((tp + tn)/40.0,fp/20.0 ,tp/20.0,tp/(tp +fp ),tp/p,2*tp/(2*tp + fp + fn))


