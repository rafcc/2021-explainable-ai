import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import roc_curve,auc
def plot_fig(name,label,num):
    roc = pd.read_csv("AI_roc.csv")
    tprs = []
    aucs = []
    mean_fpr = np.linspace(0, 1, 10000)
    plt.rcParams['font.family'] = 'Arial'
    fig, ax = plt.subplots()
    ax.grid(color='grey', linestyle='dotted', linewidth=1)
    for i in range(1,6):
        fpr = roc["ai_" + str(i) + "_x"]
        tpr = roc["ai_" + str(i) + "_y"]
        fpr,tpr = fpr.dropna(axis=0),tpr.dropna(axis=0)
        interp_tpr = np.interp(mean_fpr,fpr,tpr)
        interp_tpr[0] = 0.0
        tprs.append(interp_tpr)
        print(auc(fpr,tpr))
        aucs.append(auc(fpr,tpr))
        #ax.plot(fpr,tpr,c="grey",alpha=0.3, lw=1,linestyle="dashed")
    ax.plot([0, 1], [0, 1], linestyle="dotted", lw=2, color='grey',label='Chance', alpha=.8)

    mean_tpr = np.mean(tprs, axis=0)
    mean_tpr[-1] = 1.0
    mean_auc = auc(mean_fpr, mean_tpr)
    std_auc = np.std(aucs)
    ax.plot(mean_fpr, mean_tpr, color='grey',
        label=r'AI (AUC = %0.3f $\pm$ %0.3f)' % (mean_auc, std_auc),
        lw=2, alpha=.8)

    std_tpr = np.std(tprs, axis=0)
    tprs_upper = np.minimum(mean_tpr + std_tpr, 1)
    tprs_lower = np.maximum(mean_tpr - std_tpr, 0)
    #ax.fill_between(mean_fpr, tprs_lower, tprs_upper, color='grey', alpha=.2,label=r'$\pm$ 1 std. dev.')
    ax.fill_between(mean_fpr, tprs_lower, tprs_upper, color='grey', alpha=.2)
    tprs = []
    aucs = []
    mean_fpr = np.linspace(0, 1, 10000)

    for i in range(1,num + 1):
        fpr = roc[name + "_" + str(i) + "_x"]
        tpr = roc[name + "_" + str(i) + "_y"] 
        fpr,tpr = fpr.dropna(axis=0),tpr.dropna(axis=0)
        interp_tpr = np.interp(mean_fpr,fpr,tpr)
        interp_tpr[0] = 0.0
        tprs.append(interp_tpr)
        print(auc(fpr,tpr))
        aucs.append(auc(fpr,tpr))
        #ax.plot(fpr,tpr,c="green",alpha=0.3, lw=1,linestyle="dashed")

    mean_tpr = np.mean(tprs, axis=0)
    mean_tpr[-1] = 1.0
    mean_auc = auc(mean_fpr, mean_tpr)
    std_auc = np.std(aucs)
    ax.plot(mean_fpr, mean_tpr, color='green',
        label= label + r' (AUC = %0.3f $\pm$ %0.3f)' % (mean_auc, std_auc),
        lw=2, alpha=.8)

    std_tpr = np.std(tprs, axis=0)
    tprs_upper = np.minimum(mean_tpr + std_tpr, 1)
    tprs_lower = np.maximum(mean_tpr - std_tpr, 0)
    ax.fill_between(mean_fpr, tprs_lower, tprs_upper, color='green', alpha=.2)

    ax.legend(loc="lower right")
    tprs = []
    aucs = []
    mean_fpr = np.linspace(0, 1, 10000)

    for i in range(1,num + 1):
        fpr = roc[name + "_" + str(i) + "_ai_x"]
        tpr = roc[name +"_" + str(i) + "_ai_y"]
        fpr,tpr = fpr.dropna(axis=0),tpr.dropna(axis=0)
        interp_tpr = np.interp(mean_fpr,fpr,tpr)
        interp_tpr[0] = 0.0
        tprs.append(interp_tpr)
        print(auc(fpr,tpr))
        aucs.append(auc(fpr,tpr))
        #ax.plot(fpr,tpr,c="red",alpha=0.3, lw=1,linestyle="dashed")

    mean_tpr = np.mean(tprs, axis=0)
    mean_tpr[-1] = 1.0
    mean_auc = auc(mean_fpr, mean_tpr)
    std_auc = np.std(aucs)
    ax.plot(mean_fpr, mean_tpr, color='r',
            label= label +  r' + AI (AUC = %0.3f $\pm$ %0.3f)' % (mean_auc, std_auc),
            lw=2, alpha=.8)

    std_tpr = np.std(tprs, axis=0)
    tprs_upper = np.minimum(mean_tpr + std_tpr, 1)
    tprs_lower = np.maximum(mean_tpr - std_tpr, 0)
    ax.fill_between(mean_fpr, tprs_lower, tprs_upper, color='r', alpha=.2)
    plt.xticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
    plt.yticks([0, 0.2, 0.4, 0.6,0.8,1.0], ['0', '0.2', '0.4', '0.6','0.8','1.0'])
    ax.set(xlim=[-0.05, 1.05], ylim=[-0.05, 1.05])
    ax.set_xlabel("FPR",fontsize=12)
    ax.set_ylabel("Recall (TPR)",fontsize=12)
    ax.legend(loc="lower right")
    plt.savefig(name + ".pdf",bbox_inches='tight')


name = "expert"
label = "Expert"
plot_fig(name,label,8)
name = "fellow"
label = "Fellow"
plot_fig(name,label,10)
name = "resident"
label = "Resident"
plot_fig(name,label,9)
